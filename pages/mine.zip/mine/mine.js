// pages/mine/mine.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    mune:[
      {icon:"/static/score-11.png",
      title:"我的义工活动",
      url:""
    },
    {icon:"/static/zuoye.png",
    title:"党群服务中心",
    url:""
    },
    {
    icon:"/static/dangfei.png",
    title:"缴纳党费",
    url:""
    }
    ],
    vancell:[
      {
        icon:"friends",
        title:"绑定学(工)号"
      },
      {
        icon:"manager",
        title:"走访宿舍的情况"
      },
      {
        icon:"friends",
        title:"我为标杆院系建设出点子"
      },
      {
        icon:"live",
        title:"日行一善"
      }, 
      {
        icon:"/static/score-8.png",
        title:"学习强国"
      },
      {
        icon:"card",
        title:"积分详情"
      }
    ]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})